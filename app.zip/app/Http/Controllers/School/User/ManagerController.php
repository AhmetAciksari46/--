<?php

namespace App\Http\Controllers\School\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Traits\ApiResponser;
use App\Http\Requests\Profile\UpdateProfileRequest;

/**
 * @OA\Tag(
 *     name="ManagerUser",
 *     description="Manager kullanıcı bilgileri yönetimi (User tablosu)"
 * )
 */
class ManagerController extends Controller
{
    use ApiResponser;



    /**
     * @OA\Put(
     *     path="/api/manager/me",
     *     tags={"ManagerUser"},
     *     summary="(Manager) Kendi user bilgilerini güncelle",
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="name", type="string", example="Yeni Yönetici Adı"),
     *             @OA\Property(property="userName", type="string", example="manager1"),
     *             @OA\Property(property="email", type="string", example="manager@okul.com"),
     *             @OA\Property(property="password", type="string", example="123456"),
     *             @OA\Property(property="password_confirmation", type="string", example="123456")
     *         )
     *     ),
     *     @OA\Response(response=200, description="Güncelleme başarılı"),
     *     @OA\Response(response=422, description="Doğrulama hatası")
     * )
     */
    public function updateManagerUser(Request $request)
    {
        $user = Auth::user();

        if (!$user->isManager()) {
            return $this->errorResponse('sadece managerlar istek atabilir.', 404);
        }

        try {
            $validated = $request->validate([
                'name'      => 'sometimes|string|max:255',
                'userName'  => 'sometimes|string|max:255|unique:users,userName,' . $user->id,
                'email'     => 'sometimes|email|unique:users,email,' . $user->id,
                'password'  => 'sometimes|string|min:6|confirmed',
            ]);

            if (isset($validated['password'])) {
                $validated['password'] = Hash::make($validated['password']);
            }

            $user->update($validated);

            return $this->successResponse($user, 'Bilgileriniz başarıyla güncellendi.');
        } catch (\Exception $e) {
            return $this->errorResponse("manager güncellenirken bir hata oluştu: " . $e->getMessage(), 500);
        }
    }

    /**
     * =========================
     *  ADMIN: GET BY ID & UPDATE BY ID
     * =========================
     */

    /**
     * @OA\Get(
     *     path="/api/admin/manager/{id}",
     *     tags={"ManagerUser"},
     *     summary="(Admin) Manager user bilgilerini user_id ile getir",
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="id", in="path", required=true, @OA\Schema(type="integer")
     *     ),
     *     @OA\Response(response=200, description="Bilgiler getirildi"),
     *     @OA\Response(response=404, description="Kullanıcı bulunamadı")
     * )
     */
    public function getManagerUserById($id)
    {

        if (!auth()->user()->can('manager.view')) {
            return $this->errorResponse('Bu işlem için yetkiniz yok.', 403);
        }
        $user = User::where('role', 'manager')->with('managerProfile')->find($id);

        if (!$user) {
            return $this->errorResponse('Manager bulunamadı.', 404);
        }

        return $this->successResponse($user, 'Manager bilgileri getirildi.');
    }

    /**
     * @OA\Get(
     *     path="/api/admin/managerlist",
     *     tags={"ManagerUser"},
     *     summary="(Admin) Managerları getirir",
     *     security={{"bearerAuth":{}}},
     *     @OA\Response(response=200, description="Bilgiler getirildi"),
     *     @OA\Response(response=404, description="Kullanıcı bulunamadı")
     * )
     */
    public function managerList()
    {

        if (!auth()->user()->can('manager.view.list')) {
            return $this->errorResponse('Bu işlem için yetkiniz yok.', 403);
        }
        $managers = User::where('role', 'manager')->with('managerProfile')->get();

        if (!$managers) {
            return $this->errorResponse('Manager bulunamadı.', 404);
        }

        return $this->successResponse($managers, 'Manager listesi getirildi.');
    }


    /**
     * @OA\Put(
     *     path="/api/admin/manager/{id}",
     *     tags={"ManagerUser"},
     *     summary="(Admin) Manager user bilgilerini user_id ile güncelle",
     *     security={{"bearerAuth":{}}},
     *     @OA\Parameter(
     *         name="id", in="path", required=true, @OA\Schema(type="integer")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="name", type="string", example="Yeni Yönetici"),
     *             @OA\Property(property="userName", type="string", example="manager123"),
     *             @OA\Property(property="email", type="string", example="manager@okul.com"),
     *             @OA\Property(property="is_active", type="boolean", example=true)
     *         )
     *     ),
     *     @OA\Response(response=200, description="Güncelleme başarılı"),
     *     @OA\Response(response=404, description="Kullanıcı bulunamadı"),
     *     @OA\Response(response=422, description="Doğrulama hatası")
     * )
     */
    public function updateManagerUserById(Request $request, $id)
    {
        if (!auth()->user()->can('manager.update')) {
            return $this->errorResponse('Bu işlem için yetkiniz yok.', 403);
        }
        try {
            $user = User::where('role', 'manager')->find($id);

            if (!$user) {
                return $this->errorResponse('Manager bulunamadı.', 404);
            }

            $validated = $request->validate([
                'name'      => 'sometimes|string|max:255',
                'userName'  => 'sometimes|string|max:255|unique:users,userName,' . $user->id,
                'email'     => 'sometimes|email|unique:users,email,' . $user->id,
                'password'  => 'sometimes|string|min:6|confirmed',
                'is_active' => 'sometimes|boolean',
            ]);

            if (isset($validated['password'])) {
                $validated['password'] = Hash::make($validated['password']);
            }

            $user->update($validated);

            return $this->successResponse($user, 'Manager bilgileri admin tarafından güncellendi.');
        } catch (\Exception $e) {
            return $this->errorResponse("Doğrulama hatası: " . $e->getMessage(), 500);
        }
    }
}
